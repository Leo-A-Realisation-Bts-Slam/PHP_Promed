<?php
setlocale(LC_TIME, 'fr_FR.UTF-8', 'fra');
require_once('libraries/autoload.php');


Application::process();
