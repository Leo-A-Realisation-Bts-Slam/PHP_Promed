<div class="pictoPraticienPatient d-flex justify-content-center mt-5">
    <a href=".?controller=praticien&task=showAuth">
        <img id='praticien' src="assets/images/praticienAccueil.png" alt="accès praticien" />
    </a>
    <a href=".?controller=patient&task=showAuth">
        <img id='patient' src="assets/images/patientAccueil.png" alt="accès patient" />
    </a>
</div>