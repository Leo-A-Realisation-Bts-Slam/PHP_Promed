<?php

namespace Controllers;


class Rendez_vous extends Controller
{
    protected $modelName = "Rendez_vous";
}
