<?php

namespace Controllers;


class Adresse extends Controller
{
  protected $modelName = "Adresse";
}
