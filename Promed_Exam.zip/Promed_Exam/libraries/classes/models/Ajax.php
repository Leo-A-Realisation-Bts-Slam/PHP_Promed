<?php

namespace Models;



class Ajax extends Model
{
    protected $table = 'ajax';
}
