<?php

namespace Models;



class Patient extends Model
{
    protected $table = 'patient';
}
